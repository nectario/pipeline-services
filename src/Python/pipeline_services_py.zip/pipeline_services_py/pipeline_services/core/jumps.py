from __future__ import annotations

class JumpSignal(Exception):
    """Lightweight control signal to jump to a labeled step.
    Raise using :func:`jump_now` or :func:`jump_after`.
    """
    def __init__(self, label: str, delay_ms: int = 0):
        if not label or not str(label).strip():
            raise ValueError("label must be non-empty")
        super().__init__(f"jump to '{label}' after {int(delay_ms)}ms")
        self.label = str(label)
        self.delay_ms = max(0, int(delay_ms))

def jump_now(label: str) -> None:
    """Jump immediately to a labeled step."""
    raise JumpSignal(label, 0)

def jump_after(label: str, delay_ms: int) -> None:
    """Jump to a labeled step after a millisecond delay."""
    raise JumpSignal(label, delay_ms)
