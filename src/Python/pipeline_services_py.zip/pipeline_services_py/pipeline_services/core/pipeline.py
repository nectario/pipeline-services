from __future__ import annotations
import time
from dataclasses import dataclass
from typing import Callable, List, Optional, Any, Generic, TypeVar, Dict

from .metrics import Metrics, NoopMetrics
from .jumps import JumpSignal
from .short_circuit import ShortCircuit

T = TypeVar('T')
I = TypeVar('I')
O = TypeVar('O')

@dataclass
class _LabeledStep(Generic[T]):
    label: Optional[str]
    name: str
    fn: Callable[[T], T]

class Pipeline(Generic[T]):
    """Unary pipeline (``T -> T``) with labeled steps, short-circuiting, and jumps."""
    def __init__(self, name: str, short_circuit: bool = True, metrics: Optional[Metrics] = None):
        self.name = name
        self.short_circuit = short_circuit
        self._steps: List[_LabeledStep[T]] = []
        self._before_each: List[Callable[[T], T]] = []
        self._after_each: List[Callable[[T], T]] = []
        self._metrics: Metrics = metrics or NoopMetrics()
        self.max_jumps: int = 1_000  # guardrail

    # --- builder-like API ---
    def before_each(self, fn: Callable[[T], T]) -> 'Pipeline[T]':
        self._before_each.append(fn)
        return self
    def after_each(self, fn: Callable[[T], T]) -> 'Pipeline[T]':
        self._after_each.append(fn)
        return self
    def step(self, fn: Callable[[T], T], *, label: Optional[str]=None, name: Optional[str]=None) -> 'Pipeline[T]':
        nm = name or getattr(fn, '__name__', 'step')
        self._steps.append(_LabeledStep(label=label, name=nm, fn=fn))
        return self

    # convenience
    def add_steps(self, *fns: Callable[[T], T]) -> 'Pipeline[T]':
        for fn in fns:
            self.step(fn)
        return self

    # --- execution ---
    def run(self, inp: T, *, start_label: Optional[str] = None, run_id: Optional[str]=None) -> T:
        rec = self._metrics.on_pipeline_start(self.name, run_id or str(int(time.time()*1e6)), start_label)
        t0_run = time.perf_counter_ns()
        label_to_index: Dict[str, int] = {}
        for idx, s in enumerate(self._steps):
            if s.label:
                label_to_index[s.label] = idx

        if start_label:
            if start_label not in label_to_index:
                raise KeyError(f"Unknown start label: {start_label}")
            i = label_to_index[start_label]
        else:
            i = 0

        cur: T = inp
        jumps = 0
        last_error: Optional[BaseException] = None

        while i < len(self._steps):
            s = self._steps[i]
            rec.on_step_start(i, s.label or s.name)
            try:
                # beforeEach
                for b in self._before_each:
                    cur = b(cur)
                # actual step
                t0 = time.perf_counter_ns()
                cur = s.fn(cur)
                rec.on_step_end(i, s.label or s.name, time.perf_counter_ns()-t0, True)
                # afterEach
                for a in self._after_each:
                    cur = a(cur)
                i += 1
            except ShortCircuit as sc:
                rec.on_step_end(i, s.label or s.name, 0, True)
                cur = sc.value  # finish successfully
                break
            except JumpSignal as js:
                jumps += 1
                if jumps > self.max_jumps:
                    last_error = RuntimeError(f"max_jumps exceeded ({self.max_jumps})")
                    rec.on_step_error(i, s.label or s.name, last_error)
                    break
                # optional delay
                if js.delay_ms > 0:
                    time.sleep(js.delay_ms/1000.0)
                # compute next index
                target = js.label
                if target not in label_to_index:
                    last_error = KeyError(f"Unknown jump label: {target}")
                    rec.on_step_error(i, s.label or s.name, last_error)
                    break
                rec.on_jump(s.label or s.name, target, js.delay_ms)
                i = label_to_index[target]
            except Exception as ex:
                rec.on_step_error(i, s.label or s.name, ex)
                last_error = ex
                if self.short_circuit:
                    break
                else:
                    # keep current value and continue
                    i += 1

        rec.on_pipeline_end(last_error is None, time.perf_counter_ns()-t0_run, last_error)
        if last_error and self.short_circuit:
            # Propagate to match short-circuit semantics
            raise last_error
        return cur

    # --- convenience constructors ---
    @classmethod
    def builder(cls, name: str, *, short_circuit: bool=True, metrics: Optional[Metrics]=None) -> 'Pipeline[T]':
        return cls(name, short_circuit=short_circuit, metrics=metrics)

class Pipe(Generic[I, O]):
    """Typed pipeline (``I -> O``) with short-circuit support only (no labeling/jumps)."""
    def __init__(self, name: str, short_circuit: bool=True, metrics: Optional[Metrics]=None):
        self.name = name
        self.short_circuit = short_circuit
        self._steps: List[Callable[..., Any]] = []
        self._metrics: Metrics = metrics or NoopMetrics()

    def step(self, fn: Callable[..., Any]) -> 'Pipe[I, O]':
        self._steps.append(fn)
        return self

    def run(self, inp: I, *, run_id: Optional[str]=None) -> O:
        rec = self._metrics.on_pipeline_start(self.name, run_id or str(int(time.time()*1e6)), None)
        cur: Any = inp
        t0_run = time.perf_counter_ns()
        last_error: Optional[BaseException] = None
        for i, fn in enumerate(self._steps):
            name = getattr(fn, '__name__', f'step{i}')
            rec.on_step_start(i, name)
            try:
                t0 = time.perf_counter_ns()
                cur = fn(cur)
                rec.on_step_end(i, name, time.perf_counter_ns()-t0, True)
            except ShortCircuit as sc:
                cur = sc.value
                rec.on_step_end(i, name, 0, True)
                break
            except Exception as ex:
                rec.on_step_error(i, name, ex)
                last_error = ex
                if self.short_circuit:
                    break
        rec.on_pipeline_end(last_error is None, time.perf_counter_ns()-t0_run, last_error)
        if last_error and self.short_circuit:
            raise last_error
        return cur  # type: ignore[return-value]

class RuntimePipeline(Generic[T]):
    """Imperative, single-threaded pipeline intended for REPL/tools.

    - ``add_pre`` / ``step`` / ``add_post`` append to an internal recording and (if not ended) apply immediately.
    - ``short_circuit`` semantics match :class:`Pipeline`.
    - Not thread-safe; use per request/session.
    """
    def __init__(self, name: str, *, short_circuit: bool=True, metrics: Optional[Metrics]=None):
        self.name = name
        self.short_circuit = short_circuit
        self._pre: List[Callable[[T], T]] = []
        self._steps: List[Callable[[T], T]] = []
        self._post: List[Callable[[T], T]] = []
        self._metrics: Metrics = metrics or NoopMetrics()
        self._ended = False
        self._current: Optional[T] = None

    def reset(self, value: T) -> None:
        self._current = value
        self._ended = False

    def add_pre(self, fn: Callable[[T], T]) -> 'RuntimePipeline[T]':
        self._pre.append(fn)
        if not self._ended and self._current is not None:
            self._current = fn(self._current)  # exceptions propagate
        return self

    def step(self, fn: Callable[[T], T]) -> 'RuntimePipeline[T]':
        self._steps.append(fn)
        if not self._ended and self._current is not None:
            try:
                self._current = fn(self._current)
            except ShortCircuit as sc:
                self._current = sc.value
                self._ended = True
            except Exception:
                if self.short_circuit:
                    self._ended = True
                # else swallow error and keep current
        return self

    def add_post(self, fn: Callable[[T], T]) -> 'RuntimePipeline[T]':
        self._post.append(fn)
        if not self._ended and self._current is not None:
            self._current = fn(self._current)
        return self

    def value(self) -> Optional[T]:
        return self._current
