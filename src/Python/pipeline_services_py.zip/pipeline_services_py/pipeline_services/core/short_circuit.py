class ShortCircuit(Exception):
    """Short-circuit signal carrying a final value for the pipeline."""
    def __init__(self, value):
        super().__init__("short_circuit")
        self.value = value

def short_circuit(value):
    """Raise a :class:`ShortCircuit` to stop the pipeline and return ``value``."""
    raise ShortCircuit(value)
