from __future__ import annotations
from .finance_steps import Features
_cnt = {'v': 0}
class TypedPredicates:
    @staticmethod
    def needs_await(f: Features) -> bool:
        _cnt['v'] += 1
        return _cnt['v'] <= 2
