import json
from pipeline_services.config.json_loader import PipelineJsonLoader
from pipeline_services.examples.adapters_text import TextStripStep, TextNormalizeStep

def test_json_unary():
    spec = {
        "pipeline": "json_clean_text",
        "type": "unary",
        "shortCircuit": False,
        "steps": [
            {"$local": "pipeline_services.examples.adapters_text.TextStripStep"},
            {"$local": "pipeline_services.examples.adapters_text.TextNormalizeStep"}
        ]
    }
    p = PipelineJsonLoader()._build(spec)
    assert p.run("  hi   there ") == "hi there"
