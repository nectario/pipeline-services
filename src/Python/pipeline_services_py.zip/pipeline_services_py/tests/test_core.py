from pipeline_services.core.pipeline import Pipeline
from pipeline_services.core.short_circuit import short_circuit
from pipeline_services.core.jumps import jump_now

def test_pipeline_basic():
    p = Pipeline("t").add_steps(lambda s: s.strip(), lambda s: s.upper())
    assert p.run("  hi ") == "HI"

def test_short_circuit():
    p = Pipeline("t", short_circuit=True)
    def a(x): return x+1
    def b(x): short_circuit(5)
    def c(x): return x*100
    p.add_steps(a,b,c)
    assert p.run(1) == 5

def test_jump():
    p = Pipeline("t")
    def a(x): return x+1
    def b(x): jump_now("a")
    p.step(a, label="a").step(b, label="b")
    assert p.run(0) == 1
